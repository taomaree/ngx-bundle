module.exports = {
    "extends": "airbnb-base",
    "plugins": [
        "import"
    ],
    "import/parser": "babel-eslint",
    "parser": "babel-eslint"
};
